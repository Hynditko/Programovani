package cz.spse.prj08_javafx_fxml_login;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(LoginApp.class, args);
    }
}
